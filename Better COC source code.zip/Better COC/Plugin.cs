﻿using System;
using BepInEx;
using UnityEngine;
using Utilla;
using Photon.Pun;
using TMPro;
using UnityEngine.UI;
using Photon.Realtime;

namespace GorillaTagModTemplateProject
{
	/// <summary>
	/// This is your mod's main class.
	/// </summary>

	/* This attribute tells Utilla to look for [ModdedGameJoin] and [ModdedGameLeave] */
	[ModdedGamemode]
	[BepInDependency("org.legoandmars.gorillatag.utilla", "1.5.0")]
	[BepInPlugin(PluginInfo.GUID, PluginInfo.Name, PluginInfo.Version)]
	public class Plugin : BaseUnityPlugin
	{
		int page = 1;


		float deltaTime = 0.0f;
		private float fps = 0.0f;
		bool inRoom;
		string ri;
		GameObject left;
		GameObject right;
		GameObject ColorButton;
		GameObject BubbleButton;
		Plugin PS;
		bool isbutt;
		bool buttp;
		string Tittle = "Better COC";
		string leadtext;
		bool colorstuffon = true;
		bool bubbles;



		//color fade
		public Color Mat;
		public float TransTime = 5;
		public Color[] ColorsToFade = { Color.black, Color.green };
		private int cci = 0;
		private int tci = 1;
		private float tp;
		private int Number;




        //Paths
        string NText = "Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/CodeOfConduct_Group/CodeOfConduct/COC Text";
		string BText = "Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/CodeOfConduct_Group/CodeOfConduct";
		string BButton = "Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/ModeSelector_Group/Selector Buttons/anchor/DISABLE FOR BETA/Casual";











		void Start()
		{
			if (gameObject.name == "Left")
            {
				isbutt = true;
				InvokeRepeating("butt", 0.0f, 0.1f);
			}
			else
            {
				if (gameObject.name == "Right")
                {
					isbutt = true;
					InvokeRepeating("butt", 0.0f, 0.1f);
				}
				else
                {
					if (gameObject.name == "ColorButton")
					{
					}
					else
					{
						if (gameObject.name == "BubbleButton")
						{
						}
						else
						{
							InvokeRepeating("FPSU", 0.0f, 1.0f);
							Utilla.Events.GameInitialized += OnGameInitialized;
						}
					}
				}
            }
		}

		void OnGameInitialized(object sender, EventArgs e)
		{
			buttons();
		}

		void Update()
		{
			if (!isbutt)
            {
				if (gameObject.name != "ColorButton")
				{
					if (gameObject.name != "BubbleButton")
					{
						Trans();
						UpdateB();
					}
				}
			}
			else
            {
				GetComponent<Renderer>().material.color = PS.Mat;
			}
			if (gameObject.name == "BubbleButton")
            {
				if (PS.bubbles)
                {
					GetComponent<Renderer>().material.color = Color.green;
					GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/TurnParent/Main Camera/UnderwaterVisualEffects/UnderwaterParticleEffects/UnderwaterBubbles").SetActive(true);
				}
				else
                {
					GetComponent<Renderer>().material.color = Color.red;
					GameObject.Find("Player Objects/Player VR Controller/GorillaPlayer/TurnParent/Main Camera/UnderwaterVisualEffects/UnderwaterParticleEffects/UnderwaterBubbles").SetActive(false);
				}
            }
			if (gameObject.name == "ColorButton")
			{
				if (PS.colorstuffon)
				{
					GetComponent<Renderer>().material.color = Color.green;
					GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/SatelliteWardrobe/PushSliderColorPicker").SetActive(true);
					GameObject.Find("Environment Objects/LocalObjects_Prefab/City/CosmeticsRoomAnchor/outerstores/Bottom Floor/OutsideBuildings/WardrobeAnchor/SatelliteWardrobe/PushSliderColorPicker").SetActive(true);
				}
				else
				{
					GetComponent<Renderer>().material.color = Color.red;
					GameObject.Find("Environment Objects/LocalObjects_Prefab/TreeRoom/TreeRoomInteractables/UI/SatelliteWardrobe/PushSliderColorPicker").SetActive(false);
					GameObject.Find("Environment Objects/LocalObjects_Prefab/City/CosmeticsRoomAnchor/outerstores/Bottom Floor/OutsideBuildings/WardrobeAnchor/SatelliteWardrobe/PushSliderColorPicker").SetActive(false);
				}
			}
		}

		/* This attribute tells Utilla to call this method when a modded room is joined */
		[ModdedGamemodeJoin]
		public void OnJoin(string gamemode)
		{
			/* Activate your mod here */
			/* This code will run regardless of if the mod is enabled*/

			inRoom = true;
		}

		/* This attribute tells Utilla to call this method when a modded room is left */
		[ModdedGamemodeLeave]
		public void OnLeave(string gamemode)
		{
			/* Deactivate your mod here */
			/* This code will run regardless of if the mod is enabled*/

			inRoom = false;
		}

		void UpdateB()
		{
			int pl = 5;
			if (page == 1)
            {
				left.SetActive(false);
            }
			else
            {
				left.SetActive(true);
			}
			if (page == pl)
			{
				right.SetActive(false);
			}
			else
			{
				right.SetActive(true);
			}
			if (page < 0)
            {
				page = 1;
            }
			if (page > pl)
            {
				page = pl;
            }
			GameObject codeOfConductObject = GameObject.Find(BText);
			if (codeOfConductObject != null)
			{
				Text codeOfConductText = codeOfConductObject.GetComponent<Text>();

				if (codeOfConductText != null)
				{
					codeOfConductText.text = $"{Tittle} [{page}]";
				}
			}
			if (page == 1)
			{
				Tittle = "Better COC";
				pone();
			}
			if (page == 2)
			{
				Tittle = "Leaderboard";
				ptwo();
			}
			if (page == 3)
			{
				Tittle = "Game adjustments";
				ColorButton.SetActive(true);
				BubbleButton.SetActive(true);
				pthree();
			}
			else
            {
				ColorButton.SetActive(false);
				BubbleButton.SetActive(false);
			}
			if (page == 4)
            {
				Tittle = "Gorilla COC";
				coc();
            }
			if (page == 5)
			{
				Tittle = "Credits";
				creds();
			}
		}

		void buttons()
        {
			GameObject base10 = GameObject.Find(BButton);
			left = Instantiate(base10);
			left.transform.parent = null;
			right = Instantiate(base10);
			right.transform.parent = null;
			ColorButton = Instantiate(base10);
			ColorButton.transform.parent = null;
			BubbleButton = Instantiate(base10);
			BubbleButton.transform.parent = null;

			ModeSelectButton script = left.GetComponent<ModeSelectButton>();
			Destroy(script);
			ModeSelectButton scripts = right.GetComponent<ModeSelectButton>();
			Destroy(scripts);
			ModeSelectButton scriptss = ColorButton.GetComponent<ModeSelectButton>();
			Destroy(scriptss);
			ModeSelectButton scriptsss = BubbleButton.GetComponent<ModeSelectButton>();
			Destroy(scriptsss);

			left.transform.position = new Vector3(-68.3075f, 11.5179f, -80.9633f);
			right.transform.position = new Vector3(-67.5022f, 11.5215f, - 80.5633f);
			ColorButton.transform.position = new Vector3(-68.2075f, 12.2179f, - 80.8633f);
			ColorButton.transform.localScale = new Vector3(0.05f, 0.05f, 0.05f);
			BubbleButton.transform.position = new Vector3(-68.2075f, 12.0179f, -80.8633f);
			BubbleButton.transform.localScale = new Vector3(0.05f, 0.05f, 0.05f);

			left.name = "Left";
			right.name = "Right";
			ColorButton.name = "ColorButton";
			BubbleButton.name = "BubbleButton";

			Plugin l = left.AddComponent<Plugin>();
			l.PS = gameObject.GetComponent<Plugin>();
			Plugin r = right.AddComponent<Plugin>();
			r.PS = gameObject.GetComponent<Plugin>();
			Plugin c = ColorButton.AddComponent<Plugin>();
			c.PS = gameObject.GetComponent<Plugin>();
			Plugin b = BubbleButton.AddComponent<Plugin>();
			b.PS = gameObject.GetComponent<Plugin>();
		}





		void FPSU()
        {
			deltaTime += (Time.deltaTime - deltaTime) * 0.1f;
			fps = 1.0f / deltaTime;
			fps = Mathf.Round(fps);
		}





		void pone()
		{
			if (!PhotonNetwork.InRoom)
			{
				ri = "You are not in a room.";
			}
			else
			{
				int playerCount = PhotonNetwork.CurrentRoom.PlayerCount;
				int maxPlayers = PhotonNetwork.CurrentRoom.MaxPlayers;
				Photon.Realtime.Player masterClient = PhotonNetwork.MasterClient;
				ri = "You are in room: " + PhotonNetwork.CurrentRoom.Name + $"\n The room master is: {masterClient.NickName}\n Players in room: {playerCount}/{maxPlayers}\n In modded: {inRoom}";

			}
			int playersCount = PhotonNetwork.CountOfPlayers;
			string textv = $"{ri}\n \n \n Total players online: {playersCount}\n \n FPS: {fps}";
			GameObject codeOfConductObject = GameObject.Find(NText);
			if (codeOfConductObject != null)
			{
				Text codeOfConductText = codeOfConductObject.GetComponent<Text>();

				if (codeOfConductText != null)
				{
					codeOfConductText.text = textv;
					codeOfConductText.alignment = TextAnchor.MiddleCenter;
				}
			}
		}
		void coc()
        {
			GameObject codeOfConductObject = GameObject.Find(NText);
			if (codeOfConductObject != null)
			{
				Text codeOfConductText = codeOfConductObject.GetComponent<Text>();

				if (codeOfConductText != null)
				{
					codeOfConductText.text = @"-NO RACISM, SEXISM, HOMOPHOBIA, TRANSPHOBIA, OR OTHER BIGOTRY
-NO CHEATS OR MODS
-DO NOT HARASS OTHER PLAYERS OR INTENTIONALLY MAKE THEM UNCOMFORTABLE
-DO NOT TROLL OR GRIEF LOBBIES BY BEING UNCATCHABLE OR BY ESCAPING THE MAP. TRY TO MAKE SURE EVERYONE IS HAVING FUN
-IF SOMEONE IS BREAKING THIS CODE, PLEASE REPORT THEM
-PLEASE BE NICE GORILLAS AND HAVE A GOOD TIME";
					codeOfConductText.alignment = TextAnchor.MiddleLeft;
				}
			}
		}

		void creds()
        {
			GameObject codeOfConductObject = GameObject.Find(NText);
			if (codeOfConductObject != null)
			{
				Text codeOfConductText = codeOfConductObject.GetComponent<Text>();

				if (codeOfConductText != null)
				{
					codeOfConductText.text = "Sev - The whole thing\n Not a bird - Helping me fix the mod template\n Vemp3r - Posting the mod :)";
					codeOfConductText.alignment = TextAnchor.MiddleCenter;
				}
			}
		}

		void ptwo()
        {
			GameObject codeOfConductObject = GameObject.Find(NText);
			if (PhotonNetwork.InRoom)
			{
				string playerList = "";

				foreach (var player in PhotonNetwork.PlayerList)
				{
					string playerName = "<color=#" + GetPlayerColor(player) + ">" + player.NickName + "</color>\n";
					playerList += playerName;
				}

				leadtext = playerList;
			}
			else
			{
				leadtext = "Not in room.";
            }
			if (codeOfConductObject != null)
			{
				Text codeOfConductText = codeOfConductObject.GetComponent<Text>();

				if (codeOfConductText != null)
				{
					codeOfConductText.text = leadtext;
					codeOfConductText.alignment = TextAnchor.MiddleCenter;
				}
			}
		}
		void pthree()
        {
			string CS = bts(colorstuffon);
			string BS = bts(bubbles);
			string textv = $"Color stuff: {CS}\n \nBubbles: {BS}";
			GameObject codeOfConductObject = GameObject.Find(NText);
			if (codeOfConductObject != null)
			{
				Text codeOfConductText = codeOfConductObject.GetComponent<Text>();

				if (codeOfConductText != null)
				{
					codeOfConductText.text = textv;
					codeOfConductText.alignment = TextAnchor.MiddleCenter;
				}
			}
		}






		// Other shit
		string bts(bool cur)
		{
			if (cur)
			{
				return "On";
			}
			else
			{
				return "Off";
			}
		}

		public void Trans()
		{
			tp += Time.deltaTime / TransTime;
			Mat = Color.Lerp(ColorsToFade[cci], ColorsToFade[tci], tp);
			if (tp >= 1f)
			{
				tp = 0f;
				cci = tci;
				tci++;
				if (tci == ColorsToFade.Length)
				{
					tci = 0;
				}
			}
		}

		string GetPlayerColor(Player player)
		{
			// Check if player has custom property "PlayerColor"
			if (player.CustomProperties.TryGetValue("PlayerColor", out object colorValue))
			{
				string colorHex = (string)colorValue;
				return colorHex;
			}
			else
			{
				// Default color if no custom property is set
				return "FFFFFF"; // White
			}
		}







































		void butt()
        {
        }
		void OnTriggerEnter()
        {
			if (!buttp)
            {
				if (isbutt)
				{
					buttp = true;
					if (gameObject.name == "Left")
					{
						PS.page = PS.page - 1;
					}
					else
					{
						PS.page = PS.page + 1;
					}
				}
				if (gameObject.name == "ColorButton")
                {
					PS.colorstuffon = !PS.colorstuffon;
					buttp = true;
                }
				if (gameObject.name == "BubbleButton")
				{
					PS.bubbles = !PS.bubbles;
					buttp = true;
				}
			}
		}
		public void OnTriggerExit()
        {
			buttp = false;
        }
	}
}
