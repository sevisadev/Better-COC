﻿namespace GorillaTagModTemplateProject
{
	/// <summary>
	/// This class is used to provide information about your mod to BepInEx.
	/// </summary>
	class PluginInfo
	{
		public const string GUID = "com.Sev.gorillatag.BetterCOC";
		public const string Name = "Better COC";
		public const string Version = "1.0.0";
	}
}
